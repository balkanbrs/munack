# munack-cli

Terminal interface for Munack.

Provides:

- `munack scan`
- `munack check`
- `munack doctor`
- `munack activate`
- `munack license status`
