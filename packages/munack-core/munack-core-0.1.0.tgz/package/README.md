# @munack/core

Core scanning, registry lookup, reporting, and licensing primitives for Munack.

This package powers the Munack CLI and VS Code-compatible extension.
